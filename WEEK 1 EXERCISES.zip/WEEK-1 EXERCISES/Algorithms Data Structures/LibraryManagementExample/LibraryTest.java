package LibraryManagementExample;

/*
 * 1. UNDERSTAND SEARCH ALGORITHMS
 *
 * Linear Search: Sequentially checks each element in the collection until the target is found or the end is reached.
 * Works on both sorted and unsorted data. Simple to implement but slow for large datasets.
 *
 * Binary Search: Repeatedly divides the search space in half by comparing the target with the middle element.
 * Requires the data to be sorted. Much faster than linear search for large datasets.
 */

/*
 * 4. ANALYSIS
 *
 * Time Complexity Comparison:
 * Linear Search: O(n) - Best: O(1), Average: O(n), Worst: O(n)
 * Binary Search: O(log n) - Best: O(1), Average: O(log n), Worst: O(log n)
 *
 * When to use each algorithm:
 *
 * Use Linear Search when:
 * 1. The dataset is small (less than 100 elements)
 * 2. The data is unsorted and cannot be sorted
 * 3. The data changes frequently (sorting overhead is too high)
 * 4. The element is likely to be found early in the list
 * 5. Simplicity is more important than performance
 *
 * Use Binary Search when:
 * 1. The dataset is large (more than 1000 elements)
 * 2. The data can be sorted and remains relatively static
 * 3. Fast search performance is critical
 * 4. Search operations are performed frequently
 * 5. The data is already sorted (no sorting overhead)
 */
public class LibraryTest {
    public static void main(String[] args) {
        System.out.println("=== Library Management System ===\n");
        
        Book[] books = {
            new Book(101, "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book(102, "To Kill a Mockingbird", "Harper Lee"),
            new Book(103, "1984", "George Orwell"),
            new Book(104, "Pride and Prejudice", "Jane Austen"),
            new Book(105, "The Catcher in the Rye", "J.D. Salinger"),
            new Book(106, "Moby Dick", "Herman Melville"),
            new Book(107, "War and Peace", "Leo Tolstoy")
        };
        
        System.out.println("--- Linear Search (Unsorted) ---");
        String searchTitle = "1984";
        Book found = LibrarySearch.linearSearchByTitle(books, searchTitle);
        if (found != null) {
            System.out.println("Found: " + found);
        } else {
            System.out.println("Book not found: " + searchTitle);
        }
        
        System.out.println("\n--- Binary Search (Sorted by Title) ---");
        Book[] sortedBooks = LibrarySearch.sortBooksByTitle(books);
        found = LibrarySearch.binarySearchByTitle(sortedBooks, "Pride and Prejudice");
        if (found != null) {
            System.out.println("Found: " + found);
        } else {
            System.out.println("Book not found");
        }
        
        System.out.println("\n--- All Books (Sorted by Title) ---");
        for (Book b : sortedBooks) {
            System.out.println(b);
        }
        
        System.out.println("\n--- Time Complexity Analysis ---");
        System.out.println("Linear Search: O(n) - Simple but slow for large datasets");
        System.out.println("Binary Search: O(log n) - Fast but requires sorted data");
        System.out.println("\nUse Linear Search for small, unsorted datasets");
        System.out.println("Use Binary Search for large, sorted datasets");
    }
}