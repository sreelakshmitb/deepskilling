package FinancialForecastingExample;

/*
 * 1. UNDERSTAND RECURSIVE ALGORITHMS
 *
 * Recursion is a programming technique where a method calls itself to solve a problem by breaking it down
 * into smaller, similar subproblems. A recursive method must have a base case that stops the recursion and
 * a recursive case that calls itself with modified parameters.
 *
 * Recursion can simplify complex problems by:
 * 1. Breaking down complex problems into simpler, identical subproblems
 * 2. Providing elegant and readable solutions for problems like tree traversal, factorial, and Fibonacci
 * 3. Reducing code duplication by reusing the same logic
 * 4. Making mathematical problems easier to express and solve
 * 5. Enabling divide-and-conquer approaches like merge sort and quick sort
 */

/*
 * 4. ANALYSIS
 *
 * Time Complexity of recursive algorithm:
 * Recursive: O(n) - Makes n recursive calls, one for each year
 * Space Complexity: O(n) - Each recursive call adds a frame to the call stack
 *
 * How to optimize the recursive solution:
 * 1. Convert to iteration: Use a simple loop instead of recursion to avoid stack overhead and achieve O(1) space
 * 2. Use direct mathematical formula: Apply the compound interest formula directly using Math.pow() for O(1) time
 * 3. Use tail recursion: If the recursive call is the last operation, some compilers optimize it to avoid stack growth
 * 4. Use memoization: Cache previously computed results to avoid redundant calculations (useful for overlapping subproblems)
 * 5. Use dynamic programming: Break the problem into overlapping subproblems and solve each once
 *
 * Optimization tips for financial forecasting:
 * 1. For simple compound interest, always use Math.pow() for best performance
 * 2. For complex scenarios with variable growth rates, use iteration over recursion
 * 3. Use recursion only when the problem naturally fits a recursive structure (tree traversal, etc.)
 */
public class FinancialForecastTest {
    public static void main(String[] args) {
        System.out.println("=== Financial Forecasting Tool ===\n");
        
        FinancialForecaster.displayForecast(10000, 0.05, 1);
        FinancialForecaster.displayForecast(10000, 0.05, 5);
        FinancialForecaster.displayForecast(10000, 0.05, 10);
        FinancialForecaster.displayForecast(10000, 0.05, 20);
        
        System.out.println("\n--- Multiple Growth Rates ---");
        FinancialForecaster.displayForecast(5000, 0.03, 10);
        FinancialForecaster.displayForecast(5000, 0.07, 10);
        FinancialForecaster.displayForecast(5000, 0.10, 10);
        
        System.out.println("\n--- Time Complexity Analysis ---");
        System.out.println("Recursive: O(n) - n recursive calls");
        System.out.println("Iterative: O(n) - n loop iterations");
        System.out.println("Optimized (Math.pow): O(1) - Direct computation");
        System.out.println("\nOptimization tip: Use Math.pow() for exponential growth calculations");
        System.out.println("Recursive approach is easier to understand but has overhead");
    }
}