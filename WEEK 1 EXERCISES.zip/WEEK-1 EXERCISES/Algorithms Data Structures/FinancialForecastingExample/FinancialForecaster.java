package FinancialForecastingExample;

public class FinancialForecaster {
    
    public static double predictFutureValueRecursive(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        }
        return predictFutureValueRecursive(initialValue * (1 + growthRate), growthRate, years - 1);
    }
    
    public static double predictFutureValueIterative(double initialValue, double growthRate, int years) {
        double value = initialValue;
        for (int i = 0; i < years; i++) {
            value = value * (1 + growthRate);
        }
        return value;
    }
    
    public static double predictFutureValueOptimized(double initialValue, double growthRate, int years) {
        return initialValue * Math.pow(1 + growthRate, years);
    }
    
    public static void displayForecast(double initialValue, double growthRate, int years) {
        System.out.println("\n--- Financial Forecast ---");
        System.out.println("Initial Value: $" + initialValue);
        System.out.println("Growth Rate: " + (growthRate * 100) + "%");
        System.out.println("Years: " + years);
        
        long startTime = System.nanoTime();
        double recursiveResult = predictFutureValueRecursive(initialValue, growthRate, years);
        long endTime = System.nanoTime();
        System.out.println("Recursive: $" + String.format("%.2f", recursiveResult));
        System.out.println("Time: " + (endTime - startTime) + " ns");
        
        startTime = System.nanoTime();
        double iterativeResult = predictFutureValueIterative(initialValue, growthRate, years);
        endTime = System.nanoTime();
        System.out.println("Iterative: $" + String.format("%.2f", iterativeResult));
        System.out.println("Time: " + (endTime - startTime) + " ns");
        
        startTime = System.nanoTime();
        double optimizedResult = predictFutureValueOptimized(initialValue, growthRate, years);
        endTime = System.nanoTime();
        System.out.println("Optimized: $" + String.format("%.2f", optimizedResult));
        System.out.println("Time: " + (endTime - startTime) + " ns");
    }
}