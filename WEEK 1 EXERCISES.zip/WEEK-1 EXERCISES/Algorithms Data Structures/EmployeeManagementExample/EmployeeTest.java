package EmployeeManagementExample;

/*
 * 1. UNDERSTAND ARRAY REPRESENTATION
 *
 * Arrays are represented in contiguous blocks of memory where each element occupies the same amount of space.
 * The address of any element can be calculated using: Base Address + (index × size of each element).
 * This allows O(1) direct access to any element by its index.
 *
 * Advantages of arrays:
 * 1. Fast random access - O(1) to get or set any element
 * 2. Memory efficient - no extra pointers or overhead like in linked lists
 * 3. Cache friendly - sequential memory access is fast for traversal operations
 * 4. Simple to implement and understand
 * 5. Good for fixed-size collections where size is known in advance
 */

/*
 * 4. ANALYSIS
 *
 * Time Complexity of operations:
 * Add: O(1) - Adding at the end of array is constant time
 * Search: O(n) - Requires checking each element until found (linear search)
 * Traverse: O(n) - Visits all elements in the array
 * Delete: O(n) - Requires shifting all subsequent elements after deletion
 *
 * Limitations of arrays:
 * 1. Fixed size - Cannot grow dynamically beyond initial capacity
 * 2. Expensive insertion/deletion - Requires shifting elements for operations in the middle
 * 3. Wasted memory - May allocate more space than needed
 * 4. No built-in methods for sorting or searching
 *
 * When to use arrays:
 * 1. When the maximum size is known in advance
 * 2. When frequent random access by index is needed
 * 3. When memory overhead must be minimized
 * 4. When operations are mostly read-only or add at end
 * 5. For simple collections where flexibility is not required
 */
public class EmployeeTest {
    public static void main(String[] args) {
        System.out.println("=== Employee Management System ===\n");
        
        EmployeeManager manager = new EmployeeManager();
        
        manager.addEmployee(new Employee(101, "John Doe", "Manager", 75000));
        manager.addEmployee(new Employee(102, "Jane Smith", "Developer", 65000));
        manager.addEmployee(new Employee(103, "Bob Johnson", "Analyst", 55000));
        manager.addEmployee(new Employee(104, "Alice Brown", "Designer", 60000));
        
        manager.traverseEmployees();
        
        System.out.println("\n--- Searching Employee ---");
        Employee emp = manager.searchEmployee(102);
        if (emp != null) {
            System.out.println("Found: " + emp);
        } else {
            System.out.println("Employee not found");
        }
        
        System.out.println("\n--- Deleting Employee ---");
        manager.deleteEmployee(103);
        manager.traverseEmployees();
        
        System.out.println("\n--- Time Complexity Analysis ---");
        System.out.println("Add: O(1) - Adding at end of array");
        System.out.println("Search: O(n) - Linear search through array");
        System.out.println("Traverse: O(n) - Iterate through all elements");
        System.out.println("Delete: O(n) - Shifting elements after deletion");
        System.out.println("\nLimitations: Fixed size, expensive insertion/deletion");
    }
}