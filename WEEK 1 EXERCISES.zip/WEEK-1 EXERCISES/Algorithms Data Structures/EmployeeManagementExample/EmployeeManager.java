package EmployeeManagementExample;

public class EmployeeManager {
    private Employee[] employees;
    private int size;
    private static final int MAX_SIZE = 100;
    
    public EmployeeManager() {
        this.employees = new Employee[MAX_SIZE];
        this.size = 0;
    }
    
    public void addEmployee(Employee employee) {
        if (size < MAX_SIZE) {
            employees[size] = employee;
            size++;
            System.out.println("Employee added: " + employee.getName());
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }
    
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }
    
    public void traverseEmployees() {
        System.out.println("\n=== Employee List ===");
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
        System.out.println("Total employees: " + size);
    }
    
    public void deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[size - 1] = null;
                size--;
                System.out.println("Employee deleted: " + employeeId);
                return;
            }
        }
        System.out.println("Employee not found: " + employeeId);
    }
}