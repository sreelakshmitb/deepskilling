package SortingOrdersExample;

/*
 * 1. UNDERSTAND SORTING ALGORITHMS
 *
 * Bubble Sort: Repeatedly steps through the list, compares adjacent elements and swaps them if they are in the wrong order.
 *              Time Complexity: O(n²) average and worst case, O(n) best case when already sorted.
 *
 * Insertion Sort: Builds the final sorted array one element at a time by repeatedly picking the next element and inserting it into the correct position.
 *                 Time Complexity: O(n²) average and worst case, O(n) best case when already sorted.
 *
 * Quick Sort: Divides the array into two smaller sub-arrays around a pivot element, then recursively sorts them.
 *             Time Complexity: O(n log n) average case, O(n²) worst case when poor pivot is chosen.
 *
 * Merge Sort: Divides the array into two halves, recursively sorts them, and then merges the sorted halves.
 *             Time Complexity: O(n log n) in all cases.
 */

/*
 * 4. ANALYSIS
 *
 * Bubble Sort Performance: O(n²) - Very slow for large datasets. Each element bubbles up through the array.
 * Quick Sort Performance: O(n log n) - Much faster for large datasets. Divides and conquers.
 *
 * Why Quick Sort is generally preferred over Bubble Sort:
 * 1. Significantly faster on average - O(n log n) vs O(n²)
 * 2. Handles large datasets efficiently without performance degradation
 * 3. Sorts in-place, requiring minimal additional memory (O(log n) stack space)
 * 4. With good pivot selection strategies (like median-of-three), worst case can be avoided
 * 5. More practical for real-world applications with large order volumes
 */
public class SortingTest {
    public static void main(String[] args) {
        System.out.println("=== Sorting Customer Orders ===\n");
        
        Order[] orders = {
            new Order("ORD001", "John Doe", 299.99),
            new Order("ORD002", "Jane Smith", 49.99),
            new Order("ORD003", "Bob Johnson", 999.99),
            new Order("ORD004", "Alice Brown", 159.99),
            new Order("ORD005", "Charlie Wilson", 75.50),
            new Order("ORD006", "Diana Ross", 450.00),
            new Order("ORD007", "Edward Lee", 125.75)
        };
        
        System.out.println("--- Original Orders ---");
        for (Order o : orders) {
            System.out.println(o);
        }
        
        Order[] bubbleOrders = orders.clone();
        System.out.println("\n--- Bubble Sort ---");
        long startTime = System.nanoTime();
        SortingAlgorithms.bubbleSort(bubbleOrders);
        long endTime = System.nanoTime();
        for (Order o : bubbleOrders) {
            System.out.println(o);
        }
        System.out.println("Time: " + (endTime - startTime) + " ns");
        
        Order[] quickOrders = orders.clone();
        System.out.println("\n--- Quick Sort ---");
        startTime = System.nanoTime();
        SortingAlgorithms.quickSort(quickOrders, 0, quickOrders.length - 1);
        endTime = System.nanoTime();
        for (Order o : quickOrders) {
            System.out.println(o);
        }
        System.out.println("Time: " + (endTime - startTime) + " ns");
        
        System.out.println("\n--- Time Complexity Analysis ---");
        System.out.println("Bubble Sort: O(n²) - Best: O(n), Average: O(n²), Worst: O(n²)");
        System.out.println("Quick Sort: O(n log n) - Best: O(n log n), Average: O(n log n), Worst: O(n²)");
        System.out.println("\nQuick Sort is generally preferred because it's faster on average.");
    }
}