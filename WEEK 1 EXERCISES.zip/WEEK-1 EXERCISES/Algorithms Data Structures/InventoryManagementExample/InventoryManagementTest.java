
/*
 * INVENTORY MANAGEMENT SYSTEM
 *
 * Why data structures and algorithms are essential in handling large inventories:
 * When dealing with thousands of products, we need fast access to find, add, or update items.
 * Without proper data structures, searching through a large inventory would be extremely slow.
 * Algorithms help us organize and retrieve data efficiently, which is critical for warehouse
 * operations where workers need real-time stock information.
 *
 * Types of data structures suitable for this problem:
 * HashMap - Best for fast lookups by product ID. Provides O(1) average time for get and put.
 * ArrayList - Good for sequential access and iterating through all products.
 * TreeMap - Useful if products need to be displayed in sorted order by ID or name.
 * HashSet - Can be used to ensure unique product IDs.
 *
 * For this implementation, HashMap is the best choice because warehouse staff frequently need
 * to look up products by ID, and we need quick add, update, and delete operations.
 */
package InventoryManagementExample;
public class InventoryManagementTest {
    public static void main(String[] args) {
        System.out.println("=== Inventory Management System ===\n");
        
        InventoryManager manager = new InventoryManager();
        
        manager.addProduct(new Product("P001", "Laptop", 10, 999.99));
        manager.addProduct(new Product("P002", "Mouse", 50, 29.99));
        manager.addProduct(new Product("P003", "Keyboard", 30, 79.99));
        manager.addProduct(new Product("P004", "Monitor", 15, 299.99));
        
        manager.displayAllProducts();
        
        System.out.println("\n--- Updating Product ---");
        manager.updateProduct("P002", 45, 24.99);
        
        System.out.println("\n--- Getting Product ---");
        Product product = manager.getProduct("P003");
        if (product != null) {
            System.out.println("Found: " + product);
        }
        
        System.out.println("\n--- Deleting Product ---");
        manager.deleteProduct("P004");
        
        manager.displayAllProducts();
        
        System.out.println("\n--- Time Complexity Analysis ---");
        System.out.println("Add: O(1) - HashMap put operation");
        System.out.println("Update: O(1) - HashMap get and put operation");
        System.out.println("Delete: O(1) - HashMap remove operation");
        System.out.println("Get: O(1) - HashMap get operation");
        System.out.println("\nOptimization: Use proper hashCode() implementation to minimize collisions.");
        System.out.println("Set appropriate initial capacity to avoid frequent rehashing.");
    }
}
