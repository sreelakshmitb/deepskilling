package InventoryManagementExample;

import java.util.HashMap;
import java.util.Map;

public class InventoryManager {
    private Map<String, Product> inventory;
    
    public InventoryManager() {
        this.inventory = new HashMap<>();
    }
    
    public void addProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            System.out.println("Product already exists. Use update to modify.");
        } else {
            inventory.put(product.getProductId(), product);
            System.out.println("Product added: " + product.getProductName());
        }
    }
    
    public void updateProduct(String productId, int quantity, double price) {
        Product product = inventory.get(productId);
        if (product != null) {
            product.setQuantity(quantity);
            product.setPrice(price);
            System.out.println("Product updated: " + product.getProductName());
        } else {
            System.out.println("Product not found: " + productId);
        }
    }
    
    public void deleteProduct(String productId) {
        if (inventory.containsKey(productId)) {
            Product removed = inventory.remove(productId);
            System.out.println("Product deleted: " + removed.getProductName());
        } else {
            System.out.println("Product not found: " + productId);
        }
    }
    
    public Product getProduct(String productId) {
        return inventory.get(productId);
    }
    
    public void displayAllProducts() {
        System.out.println("\n=== Inventory ===");
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
        System.out.println("Total products: " + inventory.size());
    }
    
    public int getTotalProducts() {
        return inventory.size();
    }
}
