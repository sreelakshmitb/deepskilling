

/*
 * E-COMMERCE SEARCH FUNCTION
 *
 * Big O notation describes how an algorithm's runtime grows as the input size increases.
 * It helps us compare different approaches and choose the most efficient one.
 *
 * ANALYSIS:
 * Linear Search Best Case: O(1) - element found at first position
 * Linear Search Average Case: O(n) - element found in the middle
 * Linear Search Worst Case: O(n) - element not found or at the end
 *
 * Binary Search Best Case: O(1) - element found at middle
 * Binary Search Average Case: O(log n) - typical scenario
 * Binary Search Worst Case: O(log n) - element not found
 *
 * Binary Search requires sorted data but is much faster for large datasets.
 * For an e-commerce platform with thousands of products, Binary Search is more suitable.
 */
package SearchFunctionExample;
public class SearchTest {
    public static void main(String[] args) {
        System.out.println("=== E-commerce Search Function ===\n");
        
        Product[] products = {
            new Product("P001", "Laptop", "Electronics", 999.99),
            new Product("P002", "Mouse", "Electronics", 29.99),
            new Product("P003", "Book", "Books", 19.99),
            new Product("P004", "Phone", "Electronics", 799.99),
            new Product("P005", "Table", "Furniture", 299.99),
            new Product("P006", "Chair", "Furniture", 149.99),
            new Product("P007", "Headphones", "Electronics", 89.99)
        };
        
        System.out.println("--- Linear Search (Unsorted) ---");
        long startTime = System.nanoTime();
        int index = SearchAlgorithms.linearSearch(products, "Phone");
        long endTime = System.nanoTime();
        
        if (index != -1) {
            System.out.println("Found: " + products[index]);
            System.out.println("Index: " + index);
        } else {
            System.out.println("Product not found");
        }
        System.out.println("Time: " + (endTime - startTime) + " ns");
        
        System.out.println("\n--- Binary Search (Sorted) ---");
        Product[] sortedProducts = SearchAlgorithms.sortProductsByName(products);
        
        startTime = System.nanoTime();
        int binaryIndex = SearchAlgorithms.binarySearch(sortedProducts, "Phone");
        endTime = System.nanoTime();
        
        if (binaryIndex != -1) {
            System.out.println("Found: " + sortedProducts[binaryIndex]);
            System.out.println("Index: " + binaryIndex);
        } else {
            System.out.println("Product not found");
        }
        System.out.println("Time: " + (endTime - startTime) + " ns");
        
        System.out.println("\n--- All Products (Sorted by Name) ---");
        for (Product p : sortedProducts) {
            System.out.println(p);
        }
        
        System.out.println("\n--- Time Complexity Analysis ---");
        System.out.println("Linear Search: O(n) - Best: O(1), Average: O(n), Worst: O(n)");
        System.out.println("Binary Search: O(log n) - Best: O(1), Average: O(log n), Worst: O(log n)");
        System.out.println("\nBinary Search is more suitable for large, sorted datasets.");
    }
}
