package TaskManagementExample;

/*
 * 1. UNDERSTAND LINKED LISTS
 *
 * Singly Linked List: Each node contains data and a reference (pointer) to the next node in the sequence.
 * Traversal is only possible in one direction (forward). Memory efficient as each node only stores one pointer.
 *
 * Doubly Linked List: Each node contains data and references to both the next and previous nodes.
 * Traversal is possible in both directions. Requires more memory as each node stores two pointers.
 * Easier to delete nodes as we have access to the previous node without traversal.
 *
 * Circular Linked List: Last node points back to the first node. Can be singly or doubly linked.
 * Useful for applications that need to cycle through elements repeatedly.
 */

/*
 * 4. ANALYSIS
 *
 * Time Complexity of operations:
 * Add: O(n) - Traverses to the end of list to add (O(1) if adding at head)
 * Search: O(n) - Traverses until the element is found
 * Traverse: O(n) - Visits all nodes in the list
 * Delete: O(n) - Traverses to find and remove the node
 *
 * Advantages of linked lists over arrays for dynamic data:
 * 1. Dynamic size - Automatically grows and shrinks as elements are added or removed
 * 2. Efficient insertion and deletion - No shifting of elements required, just pointer manipulation
 * 3. Memory efficiency - Allocates exactly the memory needed for each element
 * 4. Flexibility - Easy to add or remove elements from any position without performance penalty
 * 5. No wasted memory - Unlike arrays that may allocate unused space
 */
public class TaskTest {
    public static void main(String[] args) {
        System.out.println("=== Task Management System ===\n");
        
        TaskLinkedList taskList = new TaskLinkedList();
        
        taskList.addTask(new Task(101, "Design UI", "Pending"));
        taskList.addTask(new Task(102, "Implement Login", "In Progress"));
        taskList.addTask(new Task(103, "Write Tests", "Pending"));
        taskList.addTask(new Task(104, "Deploy Application", "Not Started"));
        taskList.addTask(new Task(105, "Documentation", "Pending"));
        
        taskList.traverseTasks();
        
        System.out.println("\n--- Searching Task ---");
        Task task = taskList.searchTask(102);
        if (task != null) {
            System.out.println("Found: " + task);
        } else {
            System.out.println("Task not found");
        }
        
        System.out.println("\n--- Deleting Task ---");
        taskList.deleteTask(103);
        taskList.traverseTasks();
        
        System.out.println("\n--- Time Complexity Analysis ---");
        System.out.println("Add: O(n) - Traverse to end (or O(1) if adding at head)");
        System.out.println("Search: O(n) - Traverse until found");
        System.out.println("Traverse: O(n) - Visit all nodes");
        System.out.println("Delete: O(n) - Traverse to find and remove");
        System.out.println("\nAdvantages: Dynamic size, no shifting needed");
    }
}