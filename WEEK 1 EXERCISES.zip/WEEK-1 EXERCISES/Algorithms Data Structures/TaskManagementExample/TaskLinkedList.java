package TaskManagementExample;

public class TaskLinkedList {
    private Task head;
    private int size;
    
    public TaskLinkedList() {
        this.head = null;
        this.size = 0;
    }
    
    public void addTask(Task task) {
        if (head == null) {
            head = task;
        } else {
            Task current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(task);
        }
        size++;
        System.out.println("Task added: " + task.getTaskName());
    }
    
    public Task searchTask(int taskId) {
        Task current = head;
        while (current != null) {
            if (current.getTaskId() == taskId) {
                return current;
            }
            current = current.getNext();
        }
        return null;
    }
    
    public void traverseTasks() {
        System.out.println("\n=== Task List ===");
        Task current = head;
        while (current != null) {
            System.out.println(current);
            current = current.getNext();
        }
        System.out.println("Total tasks: " + size);
    }
    
    public void deleteTask(int taskId) {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        
        if (head.getTaskId() == taskId) {
            head = head.getNext();
            size--;
            System.out.println("Task deleted: " + taskId);
            return;
        }
        
        Task current = head;
        while (current.getNext() != null && current.getNext().getTaskId() != taskId) {
            current = current.getNext();
        }
        
        if (current.getNext() != null) {
            current.setNext(current.getNext().getNext());
            size--;
            System.out.println("Task deleted: " + taskId);
        } else {
            System.out.println("Task not found: " + taskId);
        }
    }
    
    public int getSize() {
        return size;
    }
}