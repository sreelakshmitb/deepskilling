package ProxyPatternExample;

public class RealImage implements Image {
    private String fileName;
    private boolean loaded;
    
    public RealImage(String fileName) {
        this.fileName = fileName;
        loadFromRemoteServer();
    }
    
    private void loadFromRemoteServer() {
        System.out.println("Loading image from remote server: " + fileName);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.loaded = true;
        System.out.println("Image loaded successfully: " + fileName);
    }
    
    @Override
    public void display() {
        if (loaded) {
            System.out.println("Displaying image: " + fileName);
        } else {
            System.out.println("Image not loaded yet: " + fileName);
        }
    }
    
    @Override
    public String getFileName() {
        return fileName;
    }
}