package ProxyPatternExample;

import java.util.HashMap;
import java.util.Map;

public class ProxyImage implements Image {
    private RealImage realImage;
    private String fileName;
    private static final Map<String, RealImage> cache = new HashMap<>();
    
    public ProxyImage(String fileName) {
        this.fileName = fileName;
    }
    
    @Override
    public void display() {
        if (cache.containsKey(fileName)) {
            System.out.println("Using cached image: " + fileName);
            realImage = cache.get(fileName);
        } else {
            System.out.println("First time loading: " + fileName);
            realImage = new RealImage(fileName);
            cache.put(fileName, realImage);
        }
        realImage.display();
    }
    
    @Override
    public String getFileName() {
        return fileName;
    }
}
