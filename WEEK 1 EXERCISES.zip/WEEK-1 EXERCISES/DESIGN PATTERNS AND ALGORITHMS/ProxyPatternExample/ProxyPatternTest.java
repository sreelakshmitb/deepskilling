package ProxyPatternExample;

public class ProxyPatternTest {
    public static void main(String[] args) {
        System.out.println("=== Image Viewer with Proxy Pattern ===\n");
        
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");
        Image image3 = new ProxyImage("photo3.jpg");
        Image image4 = new ProxyImage("photo1.jpg");
        Image image5 = new ProxyImage("photo2.jpg");
        
        System.out.println("1. First display of photo1.jpg (should load from server):");
        image1.display();
        System.out.println();
        
        System.out.println("2. First display of photo2.jpg (should load from server):");
        image2.display();
        System.out.println();
        
        System.out.println("3. First display of photo3.jpg (should load from server):");
        image3.display();
        System.out.println();
        
        System.out.println("4. Second display of photo1.jpg (should use cache):");
        image1.display();
        System.out.println();
        
        System.out.println("5. First display of photo1.jpg through image4 (should use cache):");
        image4.display();
        System.out.println();
        
        System.out.println("6. Second display of photo2.jpg (should use cache):");
        image2.display();
        System.out.println();
        
        System.out.println("7. Displaying all images:");
        displayAllImages(image1, image2, image3, image4, image5);
    }
    
    private static void displayAllImages(Image... images) {
        for (Image img : images) {
            System.out.println("Image: " + img.getFileName());
            img.display();
        }
        System.out.println();
    }
}