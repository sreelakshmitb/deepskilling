package AdapterPatternExample;

public class AdapterPatternTest {
    public static void main(String[] args) {
        System.out.println("=== Payment Processing System ===\n");
        
        System.out.println("1. Using PayPal:");
        PayPalGateway payPalGateway = new PayPalGateway();
        PaymentProcessor payPalProcessor = new PayPalAdapter(payPalGateway);
        payPalProcessor.processPayment(99.99);
        System.out.println("Payment Status: " + payPalProcessor.getPaymentStatus());
        System.out.println();
        
        System.out.println("2. Using Stripe:");
        StripeGateway stripeGateway = new StripeGateway();
        PaymentProcessor stripeProcessor = new StripeAdapter(stripeGateway);
        stripeProcessor.processPayment(149.50);
        System.out.println("Payment Status: " + stripeProcessor.getPaymentStatus());
        System.out.println();
        
        System.out.println("3. Using Razorpay:");
        RazorpayGateway razorpayGateway = new RazorpayGateway();
        PaymentProcessor razorpayProcessor = new RazorpayAdapter(razorpayGateway);
        razorpayProcessor.processPayment(200.00);
        System.out.println("Payment Status: " + razorpayProcessor.getPaymentStatus());
        System.out.println();
        
        System.out.println("4. Processing multiple payments with different gateways:");
        PaymentProcessor[] processors = {payPalProcessor, stripeProcessor, razorpayProcessor};
        double[] amounts = {75.25, 200.00, 50.00};
        
        for (int i = 0; i < processors.length; i++) {
            System.out.println("\nPayment " + (i + 1) + ":");
            processors[i].processPayment(amounts[i]);
            System.out.println("Status: " + processors[i].getPaymentStatus());
        }
    }
}