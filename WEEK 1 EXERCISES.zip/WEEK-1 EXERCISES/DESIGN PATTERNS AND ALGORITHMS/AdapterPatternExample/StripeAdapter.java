package AdapterPatternExample;

public class StripeAdapter implements PaymentProcessor {
    private StripeGateway stripeGateway;
    private String status;
    
    public StripeAdapter(StripeGateway stripeGateway) {
        this.stripeGateway = stripeGateway;
    }
    
    @Override
    public void processPayment(double amount) {
        long amountInCents = (long)(amount * 100);
        stripeGateway.createCharge(amountInCents);
        this.status = stripeGateway.getStripeStatus();
        System.out.println("Payment processed via Stripe: " + status);
    }
    
    @Override
    public String getPaymentStatus() {
        return status;
    }
}