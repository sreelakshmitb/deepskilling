package AdapterPatternExample;

public class RazorpayGateway {
    private String paymentId;
    private boolean success;
    
    public void initiatePayment(double rupees) {
        System.out.println("Processing Razorpay payment of ₹" + rupees);
        this.success = true;
        this.paymentId = "rzp_" + System.currentTimeMillis();
        System.out.println("Razorpay payment ID: " + paymentId);
    }
    
    public String getRazorpayStatus() {
        return success ? "COMPLETED" : "FAILED";
    }
    
    public String getPaymentId() {
        return paymentId;
    }
}
