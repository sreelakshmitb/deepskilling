package AdapterPatternExample;

public class PayPalAdapter implements PaymentProcessor {
    private PayPalGateway payPalGateway;
    private String status;
    
    public PayPalAdapter(PayPalGateway payPalGateway) {
        this.payPalGateway = payPalGateway;
    }
    
    @Override
    public void processPayment(double amount) {
        payPalGateway.makePayment(amount);
        this.status = payPalGateway.getPayPalStatus();
        System.out.println("Payment processed via PayPal: " + status);
    }
    
    @Override
    public String getPaymentStatus() {
        return status;
    }
}