package AdapterPatternExample;

public class PayPalGateway {
    private String transactionId;
    private boolean paymentSuccess;
    
    public void makePayment(double usdAmount) {
        System.out.println("Processing PayPal payment of $" + usdAmount);
        this.paymentSuccess = true;
        this.transactionId = "PP-" + System.currentTimeMillis();
        System.out.println("PayPal transaction ID: " + transactionId);
    }
    
    public String getPayPalStatus() {
        return paymentSuccess ? "SUCCESS" : "FAILED";
    }
    
    public String getTransactionId() {
        return transactionId;
    }
}