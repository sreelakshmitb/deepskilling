package AdapterPatternExample;

public class RazorpayAdapter implements PaymentProcessor {
    private RazorpayGateway razorpayGateway;
    private String status;
    
    public RazorpayAdapter(RazorpayGateway razorpayGateway) {
        this.razorpayGateway = razorpayGateway;
    }
    
    @Override
    public void processPayment(double amount) {
        double rupees = amount * 83.50;
        razorpayGateway.initiatePayment(rupees);
        this.status = razorpayGateway.getRazorpayStatus();
        System.out.println("Payment processed via Razorpay: " + status);
    }
    
    @Override
    public String getPaymentStatus() {
        return status;
    }
}