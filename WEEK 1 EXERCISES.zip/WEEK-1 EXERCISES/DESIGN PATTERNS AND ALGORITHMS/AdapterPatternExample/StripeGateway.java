package AdapterPatternExample;

public class StripeGateway {
    private String chargeId;
    private boolean completed;
    
    public void createCharge(double amountInCents) {
        System.out.println("Processing Stripe payment of $" + (amountInCents / 100));
        this.completed = true;
        this.chargeId = "ch_" + System.currentTimeMillis();
        System.out.println("Stripe charge ID: " + chargeId);
    }
    
    public String getStripeStatus() {
        return completed ? "SUCCEEDED" : "FAILED";
    }
    
    public String getChargeId() {
        return chargeId;
    }
}