package CommandPatternExample;

public class Light {
    private String location;
    private boolean isOn;
    private int brightness;
    
    public Light(String location) {
        this.location = location;
        this.isOn = false;
        this.brightness = 0;
    }
    
    public void turnOn() {
        this.isOn = true;
        this.brightness = 100;
        System.out.println(location + " light is turned ON at " + brightness + "% brightness");
    }
    
    public void turnOff() {
        this.isOn = false;
        this.brightness = 0;
        System.out.println(location + " light is turned OFF");
    }
    
    public void dim(int level) {
        if (isOn) {
            this.brightness = Math.max(0, Math.min(100, level));
            System.out.println(location + " light dimmed to " + brightness + "%");
        } else {
            System.out.println("Cannot dim " + location + " light because it's OFF");
        }
    }
    
    public boolean isOn() {
        return isOn;
    }
    
    public int getBrightness() {
        return brightness;
    }
}
