package CommandPatternExample;

import java.util.Stack;

public class RemoteControl {
    private Command currentCommand;
    private Stack<Command> commandHistory;
    private Stack<Command> undoHistory;
    private String name;
    
    public RemoteControl(String name) {
        this.name = name;
        this.commandHistory = new Stack<>();
        this.undoHistory = new Stack<>();
    }
    
    public void setCommand(Command command) {
        this.currentCommand = command;
    }
    
    public void pressButton() {
        if (currentCommand != null) {
            currentCommand.execute();
            commandHistory.push(currentCommand);
            undoHistory.clear();
            System.out.println("[" + name + "] Command executed: " + currentCommand.getDescription());
        } else {
            System.out.println("[" + name + "] No command set!");
        }
    }
    
    public void undoLastCommand() {
        if (!commandHistory.isEmpty()) {
            Command lastCommand = commandHistory.pop();
            lastCommand.undo();
            undoHistory.push(lastCommand);
            System.out.println("[" + name + "] Undo performed: " + lastCommand.getDescription());
        } else {
            System.out.println("[" + name + "] No commands to undo!");
        }
    }
    
    public void redoLastUndo() {
        if (!undoHistory.isEmpty()) {
            Command commandToRedo = undoHistory.pop();
            commandToRedo.execute();
            commandHistory.push(commandToRedo);
            System.out.println("[" + name + "] Redo performed: " + commandToRedo.getDescription());
        } else {
            System.out.println("[" + name + "] No commands to redo!");
        }
    }
    
    public void showHistory() {
        System.out.println("\n=== Command History for " + name + " (" + commandHistory.size() + " commands) ===");
        for (int i = commandHistory.size() - 1; i >= 0; i--) {
            System.out.println((i + 1) + ". " + commandHistory.get(i).getDescription());
        }
    }
    
    public void clearHistory() {
        commandHistory.clear();
        undoHistory.clear();
        System.out.println("[" + name + "] Command history cleared");
    }
}