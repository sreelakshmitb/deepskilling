package CommandPatternExample;

public class Fan {
    private String location;
    private int speed;
    private boolean isOn;
    
    public Fan(String location) {
        this.location = location;
        this.speed = 0;
        this.isOn = false;
    }
    
    public void turnOn() {
        this.isOn = true;
        this.speed = 3;
        System.out.println(location + " fan is turned ON at speed " + speed);
    }
    
    public void turnOff() {
        this.isOn = false;
        this.speed = 0;
        System.out.println(location + " fan is turned OFF");
    }
    
    public void setSpeed(int speed) {
        if (isOn) {
            this.speed = Math.max(0, Math.min(5, speed));
            System.out.println(location + " fan speed set to " + this.speed);
        } else {
            System.out.println("Cannot set speed of " + location + " fan because it's OFF");
        }
    }
    
    public boolean isOn() {
        return isOn;
    }
    
    public int getSpeed() {
        return speed;
    }
}
