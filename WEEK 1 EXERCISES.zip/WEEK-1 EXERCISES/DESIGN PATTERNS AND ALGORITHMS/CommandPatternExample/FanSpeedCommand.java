package CommandPatternExample;

public class FanSpeedCommand implements Command {
    private Fan fan;
    private int speed;
    private int previousSpeed;
    
    public FanSpeedCommand(Fan fan, int speed) {
        this.fan = fan;
        this.speed = speed;
        this.previousSpeed = 0;
    }
    
    @Override
    public void execute() {
        previousSpeed = fan.getSpeed();
        fan.setSpeed(speed);
    }
    
    @Override
    public void undo() {
        fan.setSpeed(previousSpeed);
    }
    
    @Override
    public String getDescription() {
        return "Set " + fan.getClass().getSimpleName() + " speed to " + speed;
    }
}