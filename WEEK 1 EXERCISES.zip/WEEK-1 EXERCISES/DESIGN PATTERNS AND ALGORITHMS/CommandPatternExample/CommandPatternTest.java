package CommandPatternExample;

public class CommandPatternTest {
    public static void main(String[] args) {
        System.out.println("=== Home Automation System ===\n");
        
        Light livingRoomLight = new Light("Living Room");
        Light kitchenLight = new Light("Kitchen");
        Light bedroomLight = new Light("Bedroom");
        
        Fan livingRoomFan = new Fan("Living Room");
        Fan bedroomFan = new Fan("Bedroom");
        
        Command livingRoomOn = new LightOnCommand(livingRoomLight);
        Command livingRoomOff = new LightOffCommand(livingRoomLight);
        Command livingRoomDim = new LightDimCommand(livingRoomLight, 50);
        Command livingRoomBright = new LightDimCommand(livingRoomLight, 100);
        
        Command kitchenOn = new LightOnCommand(kitchenLight);
        Command kitchenOff = new LightOffCommand(kitchenLight);
        
        Command bedroomOn = new LightOnCommand(bedroomLight);
        Command bedroomOff = new LightOffCommand(bedroomLight);
        
        Command fanOn = new FanOnCommand(livingRoomFan);
        Command fanOff = new FanOffCommand(livingRoomFan);
        Command fanSpeed = new FanSpeedCommand(livingRoomFan, 4);
        
        Command bedroomFanOn = new FanOnCommand(bedroomFan);
        Command bedroomFanOff = new FanOffCommand(bedroomFan);
        Command bedroomFanSpeed = new FanSpeedCommand(bedroomFan, 2);
        
        RemoteControl mainRemote = new RemoteControl("Main Remote");
        RemoteControl bedroomRemote = new RemoteControl("Bedroom Remote");
        
        System.out.println("--- Living Room Operations ---");
        mainRemote.setCommand(livingRoomOn);
        mainRemote.pressButton();
        
        mainRemote.setCommand(livingRoomDim);
        mainRemote.pressButton();
        
        mainRemote.setCommand(livingRoomBright);
        mainRemote.pressButton();
        
        mainRemote.setCommand(livingRoomOff);
        mainRemote.pressButton();
        System.out.println();
        
        System.out.println("--- Undo Operations ---");
        mainRemote.undoLastCommand();
        mainRemote.undoLastCommand();
        mainRemote.undoLastCommand();
        mainRemote.undoLastCommand();
        System.out.println();
        
        System.out.println("--- Kitchen Operations ---");
        mainRemote.setCommand(kitchenOn);
        mainRemote.pressButton();
        
        mainRemote.setCommand(kitchenOff);
        mainRemote.pressButton();
        System.out.println();
        
        System.out.println("--- Living Room Fan Operations ---");
        mainRemote.setCommand(fanOn);
        mainRemote.pressButton();
        
        mainRemote.setCommand(fanSpeed);
        mainRemote.pressButton();
        
        mainRemote.setCommand(fanOff);
        mainRemote.pressButton();
        System.out.println();
        
        System.out.println("--- Bedroom Operations ---");
        bedroomRemote.setCommand(bedroomOn);
        bedroomRemote.pressButton();
        
        bedroomRemote.setCommand(new LightDimCommand(bedroomLight, 30));
        bedroomRemote.pressButton();
        
        bedroomRemote.setCommand(bedroomOff);
        bedroomRemote.pressButton();
        System.out.println();
        
        System.out.println("--- Bedroom Fan Operations ---");
        bedroomRemote.setCommand(bedroomFanOn);
        bedroomRemote.pressButton();
        
        bedroomRemote.setCommand(bedroomFanSpeed);
        bedroomRemote.pressButton();
        
        bedroomRemote.setCommand(bedroomFanOff);
        bedroomRemote.pressButton();
        System.out.println();
        
        System.out.println("--- Command History ---");
        mainRemote.showHistory();
        System.out.println();
        bedroomRemote.showHistory();
        System.out.println();
        
        System.out.println("--- Macro Commands (Multiple operations) ---");
        System.out.println("Creating macro: Turn ON living room light + Turn ON fan");
        Command macroCommand = new MacroCommand(new Command[]{livingRoomOn, fanOn});
        mainRemote.setCommand(macroCommand);
        mainRemote.pressButton();
        System.out.println();
        
        System.out.println("Creating macro: Dim living room light + Set fan speed 3");
        Command macroCommand2 = new MacroCommand(new Command[]{
            new LightDimCommand(livingRoomLight, 40),
            new FanSpeedCommand(livingRoomFan, 3)
        });
        mainRemote.setCommand(macroCommand2);
        mainRemote.pressButton();
        System.out.println();
        
        System.out.println("--- Undo all commands ---");
        for (int i = 0; i < 12; i++) {
            mainRemote.undoLastCommand();
        }
    }
}