package CommandPatternExample;

public class MacroCommand implements Command {
    private Command[] commands;
    
    public MacroCommand(Command[] commands) {
        this.commands = commands;
    }
    
    @Override
    public void execute() {
        System.out.println("Executing macro command with " + commands.length + " operations:");
        for (Command command : commands) {
            command.execute();
        }
    }
    
    @Override
    public void undo() {
        System.out.println("Undoing macro command:");
        for (int i = commands.length - 1; i >= 0; i--) {
            commands[i].undo();
        }
    }
    
    @Override
    public String getDescription() {
        StringBuilder desc = new StringBuilder("Macro: ");
        for (int i = 0; i < commands.length; i++) {
            desc.append(commands[i].getDescription());
            if (i < commands.length - 1) {
                desc.append(" + ");
            }
        }
        return desc.toString();
    }
}