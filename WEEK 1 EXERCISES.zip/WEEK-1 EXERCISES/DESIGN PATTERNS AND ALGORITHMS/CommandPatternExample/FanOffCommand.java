package CommandPatternExample;

public class FanOffCommand implements Command {
    private Fan fan;
    
    public FanOffCommand(Fan fan) {
        this.fan = fan;
    }
    
    @Override
    public void execute() {
        fan.turnOff();
    }
    
    @Override
    public void undo() {
        fan.turnOn();
    }
    
    @Override
    public String getDescription() {
        return "Turn " + fan.getClass().getSimpleName() + " OFF";
    }
}