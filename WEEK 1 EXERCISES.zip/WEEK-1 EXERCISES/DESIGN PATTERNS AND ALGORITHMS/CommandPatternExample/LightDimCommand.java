package CommandPatternExample;

public class LightDimCommand implements Command {
    private Light light;
    private int level;
    private int previousLevel;
    
    public LightDimCommand(Light light, int level) {
        this.light = light;
        this.level = level;
        this.previousLevel = 100;
    }
    
    @Override
    public void execute() {
        previousLevel = light.getBrightness();
        light.dim(level);
    }
    
    @Override
    public void undo() {
        light.dim(previousLevel);
    }
    
    @Override
    public String getDescription() {
        return "Dim " + light.getClass().getSimpleName() + " to " + level + "%";
    }
}