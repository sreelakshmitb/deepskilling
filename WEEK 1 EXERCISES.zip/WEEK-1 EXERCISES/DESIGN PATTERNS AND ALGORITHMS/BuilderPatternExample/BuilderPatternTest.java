package BuilderPatternExample;

public class BuilderPatternTest {
    public static void main(String[] args) {
        System.out.println("--- Testing Builder Pattern --- \n");
        
        Computer basicComputer = new Computer.Builder("Intel Core i5-12400", "8GB DDR4")
                .build();
        
        System.out.println("1. Basic Computer (Default Configuration):");
        System.out.println(basicComputer);
        System.out.println();
        
        Computer gamingComputer = new Computer.Builder("Intel Core i9-13900K", "32GB DDR5")
                .storage("2TB NVMe SSD")
                .graphicsCard("NVIDIA RTX 4090 24GB")
                .bluetoothEnabled(true)
                .operatingSystem("Windows 11 Pro")
                .build();
        
        System.out.println("2. Gaming Computer (High-End Configuration):");
        System.out.println(gamingComputer);
        System.out.println();
        
        Computer workComputer = new Computer.Builder("AMD Ryzen 7 7800X3D", "16GB DDR5")
                .storage("1TB NVMe SSD")
                .bluetoothEnabled(true)
                .operatingSystem("Ubuntu 22.04 LTS")
                .build();
        
        System.out.println("3. Work Computer (Developer Configuration):");
        System.out.println(workComputer);
        System.out.println();
        
        Computer budgetComputer = new Computer.Builder("Intel Core i3-12100", "4GB DDR4")
                .storage("128GB SSD")
                .operatingSystem("Linux Mint")
                .build();
        
        System.out.println("4. Budget Computer (Basic Configuration):");
        System.out.println(budgetComputer);
        System.out.println();
        
        Computer mediaComputer = new Computer.Builder("AMD Ryzen 5 5600G", "16GB DDR4")
                .storage("2TB HDD + 256GB SSD")
                .graphicsCard("Integrated Radeon Graphics")
                .bluetoothEnabled(true)
                .operatingSystem("Windows 11 Home")
                .build();
        
        System.out.println("5. Media Computer (Home Theater Configuration):");
        System.out.println(mediaComputer);
    }
}