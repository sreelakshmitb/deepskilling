package BuilderPatternExample;

public class Computer {
    private final String cpu;
    private final String ram;
    private final String storage;
    private final String graphicsCard;
    private final boolean bluetoothEnabled;
    private final String operatingSystem;
    
    private Computer(Builder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
        this.graphicsCard = builder.graphicsCard;
        this.bluetoothEnabled = builder.bluetoothEnabled;
        this.operatingSystem = builder.operatingSystem;
    }
    
    public static class Builder {
        private final String cpu;
        private final String ram;
        private String storage = "256GB SSD";
        private String graphicsCard = "Integrated Graphics";
        private boolean bluetoothEnabled = false;
        private String operatingSystem = "Windows 11";
        
        public Builder(String cpu, String ram) {
            this.cpu = cpu;
            this.ram = ram;
        }
        
        public Builder storage(String storage) {
            this.storage = storage;
            return this;
        }
        
        public Builder graphicsCard(String graphicsCard) {
            this.graphicsCard = graphicsCard;
            return this;
        }
        
        public Builder bluetoothEnabled(boolean bluetoothEnabled) {
            this.bluetoothEnabled = bluetoothEnabled;
            return this;
        }
        
        public Builder operatingSystem(String operatingSystem) {
            this.operatingSystem = operatingSystem;
            return this;
        }
        
        public Computer build() {
            return new Computer(this);
        }
    }
    
    public String getCpu() { return cpu; }
    public String getRam() { return ram; }
    public String getStorage() { return storage; }
    public String getGraphicsCard() { return graphicsCard; }
    public boolean isBluetoothEnabled() { return bluetoothEnabled; }
    public String getOperatingSystem() { return operatingSystem; }
    
    @Override
    public String toString() {
        return "Computer{" +
                "\n  CPU: " + cpu +
                "\n  RAM: " + ram +
                "\n  Storage: " + storage +
                "\n  Graphics Card: " + graphicsCard +
                "\n  Bluetooth: " + (bluetoothEnabled ? "Enabled" : "Disabled") +
                "\n  Operating System: " + operatingSystem +
                "\n}";
    }
}