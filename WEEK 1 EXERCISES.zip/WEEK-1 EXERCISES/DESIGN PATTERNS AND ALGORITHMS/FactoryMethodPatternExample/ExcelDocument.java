package FactoryMethodPatternExample;

public class ExcelDocument implements Document {
    @Override
    public void open() {
        System.out.println("Opening Microsoft Excel Spreadsheet (.xlsx)...");
    }

    @Override
    public void close() {
        System.out.println("Closing Microsoft Excel Spreadsheet.");
    }
}
