package FactoryMethodPatternExample;

public class FactoryMethodTest {
    public static void main(String[] args) {
        System.out.println("Testing Factory Method Pattern\n");
 DocumentFactory wordFactory = new WordDocumentFactory();
        Document myWordDoc = wordFactory.createDocument();
        myWordDoc.open();
        myWordDoc.close();
        System.out.println();
       DocumentFactory pdfFactory = new PdfDocumentFactory();
        Document myPdfDoc = pdfFactory.createDocument();
        myPdfDoc.open();
        myPdfDoc.close();
        System.out.println();

         DocumentFactory excelFactory = new ExcelDocumentFactory();
        Document myExcelDoc = excelFactory.createDocument();
        myExcelDoc.open();
        myExcelDoc.close();
    }
}
