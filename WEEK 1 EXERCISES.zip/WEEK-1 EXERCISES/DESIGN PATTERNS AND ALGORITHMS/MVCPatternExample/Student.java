package MVCPatternExample;

public class Student {
    private String name;
    private String id;
    private String grade;
    private String email;
    private String department;
    
    public Student(String name, String id, String grade) {
        this.name = name;
        this.id = id;
        this.grade = grade;
        this.email = "";
        this.department = "";
    }
    
    public Student(String name, String id, String grade, String email, String department) {
        this.name = name;
        this.id = id;
        this.grade = grade;
        this.email = email;
        this.department = department;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getGrade() {
        return grade;
    }
    
    public void setGrade(String grade) {
        this.grade = grade;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
}
