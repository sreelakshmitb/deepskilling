package MVCPatternExample;

public class StudentController {
    private Student model;
    private StudentView view;
    
    public StudentController(Student model, StudentView view) {
        this.model = model;
        this.view = view;
    }
    
    public void setStudentName(String name) {
        model.setName(name);
    }
    
    public String getStudentName() {
        return model.getName();
    }
    
    public void setStudentId(String id) {
        model.setId(id);
    }
    
    public String getStudentId() {
        return model.getId();
    }
    
    public void setStudentGrade(String grade) {
        model.setGrade(grade);
    }
    
    public String getStudentGrade() {
        return model.getGrade();
    }
    
    public void setStudentEmail(String email) {
        model.setEmail(email);
    }
    
    public String getStudentEmail() {
        return model.getEmail();
    }
    
    public void setStudentDepartment(String department) {
        model.setDepartment(department);
    }
    
    public String getStudentDepartment() {
        return model.getDepartment();
    }
    
    public void updateView() {
        view.displayStudentDetails(model);
    }
    
    public void updateStudent(String name, String id, String grade) {
        model.setName(name);
        model.setId(id);
        model.setGrade(grade);
        view.displayMessage("Student updated successfully!");
        updateView();
    }
    
    public void updateStudent(String name, String id, String grade, String email, String department) {
        model.setName(name);
        model.setId(id);
        model.setGrade(grade);
        model.setEmail(email);
        model.setDepartment(department);
        view.displayMessage("Student updated successfully!");
        updateView();
    }
}