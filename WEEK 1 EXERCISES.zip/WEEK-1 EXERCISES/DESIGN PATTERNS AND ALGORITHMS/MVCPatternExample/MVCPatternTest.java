package MVCPatternExample;

public class MVCPatternTest {
    public static void main(String[] args) {
        System.out.println("=== Student Management System (MVC Pattern) ===\n");
        
        StudentView view = new StudentView();
        
        Student student1 = new Student("John Doe", "S001", "A");
        StudentController controller1 = new StudentController(student1, view);
        
        System.out.println("1. Initial Student Details:");
        controller1.updateView();
        
        System.out.println("2. Updating Student Details:");
        controller1.updateStudent("John Doe", "S001", "A+", "john.doe@university.edu", "Computer Science");
        
        System.out.println("3. Creating Another Student:");
        Student student2 = new Student("Jane Smith", "S002", "B+", "jane.smith@university.edu", "Mathematics");
        StudentController controller2 = new StudentController(student2, view);
        controller2.updateView();
        
        System.out.println("4. Updating Jane's Grade:");
        controller2.setStudentGrade("A-");
        controller2.updateView();
        
        System.out.println("5. Creating Multiple Students:");
        Student[] students = {
            new Student("Alice Johnson", "S003", "A", "alice.j@university.edu", "Physics"),
            new Student("Bob Williams", "S004", "B", "bob.w@university.edu", "Chemistry"),
            new Student("Carol Davis", "S005", "C+", "carol.d@university.edu", "Biology")
        };
        
        StudentController[] controllers = new StudentController[students.length];
        for (int i = 0; i < students.length; i++) {
            controllers[i] = new StudentController(students[i], view);
        }
        
        view.displayAllStudents(students);
        
        System.out.println("6. Updating Multiple Students:");
        controllers[0].setStudentGrade("A+");
        controllers[1].setStudentGrade("B+");
        controllers[2].setStudentGrade("B-");
        
        for (StudentController controller : controllers) {
            controller.updateView();
        }
        
        System.out.println("7. Student Search:");
        searchStudent(students, "S003");
        searchStudent(students, "S006");
        
        System.out.println("8. Student Grade Summary:");
        displayGradeSummary(students);
        
        System.out.println("9. Creating Student with All Details:");
        Student student3 = new Student("David Brown", "S006", "A", "david.b@university.edu", "Engineering");
        StudentController controller3 = new StudentController(student3, view);
        controller3.updateView();
        
        System.out.println("10. Batch Update:");
        batchUpdate(controllers, "A", "Excellent Performance!");
        
        System.out.println("11. Final Student List:");
        view.displayAllStudents(students);
        
        System.out.println("12. Adding New Student via Controller:");
        Student student4 = new Student("Emma Wilson", "S007", "B+");
        StudentController controller4 = new StudentController(student4, view);
        controller4.setStudentEmail("emma.w@university.edu");
        controller4.setStudentDepartment("Psychology");
        controller4.updateView();
        
        System.out.println("13. Student Count:");
        System.out.println("Total Students: " + (students.length + 4));
    }
    
    private static void searchStudent(Student[] students, String id) {
        boolean found = false;
        for (Student student : students) {
            if (student.getId().equals(id)) {
                System.out.println("Found student: " + student.getName() + 
                                 " (ID: " + student.getId() + ")");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Student with ID " + id + " not found.");
        }
    }
    
    private static void displayGradeSummary(Student[] students) {
        System.out.println("\n--- Grade Distribution ---");
        int aCount = 0, bCount = 0, cCount = 0, otherCount = 0;
        for (Student student : students) {
            String grade = student.getGrade();
            if (grade.startsWith("A")) {
                aCount++;
            } else if (grade.startsWith("B")) {
                bCount++;
            } else if (grade.startsWith("C")) {
                cCount++;
            } else {
                otherCount++;
            }
        }
        System.out.println("A Grades: " + aCount);
        System.out.println("B Grades: " + bCount);
        System.out.println("C Grades: " + cCount);
        System.out.println("Other: " + otherCount);
    }
    
    private static void batchUpdate(StudentController[] controllers, String grade, String message) {
        System.out.println("\n--- Batch Update ---");
        System.out.println("Setting all grades to: " + grade);
        System.out.println("Message: " + message);
        for (StudentController controller : controllers) {
            controller.setStudentGrade(grade);
            controller.updateView();
        }
    }
}