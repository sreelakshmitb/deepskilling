package MVCPatternExample;

public class StudentView {
    
    public void displayStudentDetails(Student student) {
        System.out.println("========================================");
        System.out.println("           STUDENT DETAILS              ");
        System.out.println("========================================");
        System.out.println("Student ID    : " + student.getId());
        System.out.println("Student Name  : " + student.getName());
        System.out.println("Grade         : " + student.getGrade());
        if (!student.getEmail().isEmpty()) {
            System.out.println("Email         : " + student.getEmail());
        }
        if (!student.getDepartment().isEmpty()) {
            System.out.println("Department    : " + student.getDepartment());
        }
        System.out.println("========================================\n");
    }
    
    public void displayStudentSummary(Student student) {
        System.out.println("[" + student.getId() + "] " + student.getName() + 
                          " - Grade: " + student.getGrade());
    }
    
    public void displayAllStudents(Student[] students) {
        System.out.println("========================================");
        System.out.println("         ALL STUDENTS LIST              ");
        System.out.println("========================================");
        for (Student student : students) {
            System.out.println("ID: " + student.getId() + " | Name: " + student.getName() + 
                             " | Grade: " + student.getGrade());
        }
        System.out.println("========================================\n");
    }
    
    public void displayMessage(String message) {
        System.out.println(">> " + message);
    }
}
