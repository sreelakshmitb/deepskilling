package ObserverPatternExample;

public interface Observer {
    void update(String stockSymbol, double price);
    String getName();
}
