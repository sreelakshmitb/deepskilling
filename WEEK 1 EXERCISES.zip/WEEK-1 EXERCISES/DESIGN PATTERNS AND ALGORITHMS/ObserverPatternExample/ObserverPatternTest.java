package ObserverPatternExample;

public class ObserverPatternTest {
    public static void main(String[] args) {
        System.out.println("=== Stock Market Monitoring System ===\n");
        
        StockMarket appleStock = new StockMarket("AAPL", 150.00);
        StockMarket googleStock = new StockMarket("GOOGL", 2800.00);
        StockMarket teslaStock = new StockMarket("TSLA", 250.00);
        
        Observer mobileApp1 = new MobileApp("Mobile Trader");
        Observer mobileApp2 = new MobileApp("Stock Wizard");
        Observer webApp1 = new WebApp("Web Analyst");
        Observer webApp2 = new WebApp("Portfolio Manager");
        Observer tradingBot1 = new TradingBot("AutoTrader Pro", 155.00);
        Observer tradingBot2 = new TradingBot("Quantum Trader", 2750.00);
        
        System.out.println("--- Registering Observers for Apple Stock ---");
        appleStock.registerObserver(mobileApp1);
        appleStock.registerObserver(webApp1);
        appleStock.registerObserver(tradingBot1);
        appleStock.registerObserver(mobileApp2);
        appleStock.registerObserver(webApp2);
        System.out.println();
        
        System.out.println("--- Apple Stock Price Updates ---");
        appleStock.setPrice(152.50);
        appleStock.setPrice(148.75);
        appleStock.setPrice(156.25);
        System.out.println();
        
        System.out.println("--- Deregistering one observer from Apple ---");
        appleStock.deregisterObserver(mobileApp2);
        System.out.println();
        
        appleStock.setPrice(160.00);
        System.out.println();
        
        System.out.println("--- Google Stock Price Updates ---");
        googleStock.registerObserver(webApp1);
        googleStock.registerObserver(tradingBot2);
        googleStock.registerObserver(mobileApp1);
        System.out.println();
        
        googleStock.setPrice(2825.00);
        googleStock.setPrice(2790.00);
        googleStock.setPrice(2760.00);
        System.out.println();
        
        System.out.println("--- Tesla Stock Price Updates ---");
        teslaStock.registerObserver(mobileApp1);
        teslaStock.registerObserver(webApp2);
        teslaStock.registerObserver(tradingBot1);
        System.out.println();
        
        teslaStock.setPrice(248.50);
        teslaStock.setPrice(255.75);
        teslaStock.setPrice(262.00);
        System.out.println();
        
        System.out.println("--- Summary of all registered observers ---");
        System.out.println("Apple Stock Observers: " + appleStock.getSymbol());
        appleStock.setPrice(appleStock.getPrice());
        System.out.println();
        System.out.println("Google Stock Observers: " + googleStock.getSymbol());
        googleStock.setPrice(googleStock.getPrice());
        System.out.println();
        System.out.println("Tesla Stock Observers: " + teslaStock.getSymbol());
        teslaStock.setPrice(teslaStock.getPrice());
    }
}
