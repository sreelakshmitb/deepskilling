package ObserverPatternExample;

public class MobileApp implements Observer {
    private String name;
    
    public MobileApp(String name) {
        this.name = name;
    }
    
    @Override
    public void update(String stockSymbol, double price) {
        System.out.println("MobileApp '" + name + "' - Stock " + stockSymbol + 
                          " is now $" + price);
        sendPushNotification(stockSymbol, price);
    }
    
    private void sendPushNotification(String stockSymbol, double price) {
        System.out.println("  >> Push notification sent to " + name + "'s mobile device");
        System.out.println("  >> Alert: " + stockSymbol + " is trading at $" + price);
    }
    
    @Override
    public String getName() {
        return name;
    }
}