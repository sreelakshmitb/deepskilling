package ObserverPatternExample;

public class WebApp implements Observer {
    private String name;
    
    public WebApp(String name) {
        this.name = name;
    }
    
    @Override
    public void update(String stockSymbol, double price) {
        System.out.println("WebApp '" + name + "' - Stock " + stockSymbol + 
                          " is now $" + price);
        updateDashboard(stockSymbol, price);
        analyzeStock(stockSymbol, price);
    }
    
    private void updateDashboard(String stockSymbol, double price) {
        System.out.println("  >> Dashboard updated for " + name);
        System.out.println("  >> " + stockSymbol + " price: $" + price);
    }
    
    private void analyzeStock(String stockSymbol, double price) {
        if (price > 100) {
            System.out.println("  >> Analysis: " + stockSymbol + " is performing well!");
        } else {
            System.out.println("  >> Analysis: " + stockSymbol + " might be undervalued.");
        }
    }
    
    @Override
    public String getName() {
        return name;
    }
}