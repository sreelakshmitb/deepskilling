package ObserverPatternExample;

public class TradingBot implements Observer {
    private String name;
    private double threshold;
    
    public TradingBot(String name, double threshold) {
        this.name = name;
        this.threshold = threshold;
    }
    
    @Override
    public void update(String stockSymbol, double price) {
        System.out.println("TradingBot '" + name + "' - Stock " + stockSymbol + 
                          " is now $" + price);
        checkAndExecuteTrade(stockSymbol, price);
    }
    
    private void checkAndExecuteTrade(String stockSymbol, double price) {
        System.out.println("  >> Analyzing " + stockSymbol + " for trading opportunities...");
        if (price > threshold) {
            System.out.println("  >> SELL signal detected! Price $" + price + " above threshold $" + threshold);
            System.out.println("  >> Executing sell order for " + stockSymbol);
        } else if (price < threshold * 0.9) {
            System.out.println("  >> BUY signal detected! Price $" + price + " below threshold $" + threshold);
            System.out.println("  >> Executing buy order for " + stockSymbol);
        } else {
            System.out.println("  >> No trading action required. Price within normal range.");
        }
    }
    
    @Override
    public String getName() {
        return name;
    }
}