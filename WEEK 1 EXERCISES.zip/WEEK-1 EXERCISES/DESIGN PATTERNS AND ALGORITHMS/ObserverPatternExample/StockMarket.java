package ObserverPatternExample;

import java.util.ArrayList;
import java.util.List;

public class StockMarket implements Stock {
    private List<Observer> observers;
    private String symbol;
    private double price;
    
    public StockMarket(String symbol, double initialPrice) {
        this.symbol = symbol;
        this.price = initialPrice;
        this.observers = new ArrayList<>();
    }
    
    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
        System.out.println(observer.getName() + " registered for " + symbol);
    }
    
    @Override
    public void deregisterObserver(Observer observer) {
        observers.remove(observer);
        System.out.println(observer.getName() + " deregistered from " + symbol);
    }
    
    @Override
    public void notifyObservers() {
        System.out.println("\n=== Notifying observers for " + symbol + " ===");
        for (Observer observer : observers) {
            observer.update(symbol, price);
        }
    }
    
    @Override
    public void setPrice(double price) {
        if (this.price != price) {
            double oldPrice = this.price;
            this.price = price;
            System.out.println("\n=== Stock Update: " + symbol + " price changed from $" + 
                              oldPrice + " to $" + price + " ===");
            notifyObservers();
        }
    }
    
    @Override
    public double getPrice() {
        return price;
    }
    
    @Override
    public String getSymbol() {
        return symbol;
    }
}