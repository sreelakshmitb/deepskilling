package SingletonPatternExample;

public class SingletonTest {
    public static void main(String[] args) {
        System.out.println("--- Testing Singleton Pattern Implementation ---");

        Logger logger1 = Logger.getInstance();
        logger1.log("First event captured.");

       Logger logger2 = Logger.getInstance();
        logger2.log("Second event captured.");
 System.out.println("\nChecking memory addresses equality:");
        System.out.println("Instance 1 HashCode: " + logger1.hashCode());
        System.out.println("Instance 2 HashCode: " + logger2.hashCode());

        if (logger1 == logger2) {
            System.out.println("SUCCESS: Both variables reference the identical unique instance.");
        } else {
            System.out.println("FAILURE: Multiple instances were found.");
        }
    }
}