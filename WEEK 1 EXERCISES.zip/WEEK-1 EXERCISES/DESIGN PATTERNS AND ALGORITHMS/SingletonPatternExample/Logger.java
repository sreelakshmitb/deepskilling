package SingletonPatternExample;
public class Logger {
    private static Logger instance;
 private Logger() {
       System.out.println("Logger Instance Created Internal Lifecycle.");
    }
public static synchronized Logger getInstance() {
        if (instance == null) {
            instance = new Logger(); 
        }
        return instance;
    }

  public void log(String message) {
        System.out.println("[LOG]: " + message);
    }
}