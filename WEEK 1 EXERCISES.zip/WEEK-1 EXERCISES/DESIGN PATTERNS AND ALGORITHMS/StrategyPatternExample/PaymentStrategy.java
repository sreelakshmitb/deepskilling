package StrategyPatternExample;

public interface PaymentStrategy {
    void pay(double amount);
    String getPaymentMethod();
    String getPaymentDetails();
}