package StrategyPatternExample;

public class PayPalPayment implements PaymentStrategy {
    private String email;
    
    public PayPalPayment(String email) {
        this.email = email;
    }
    
    @Override
    public void pay(double amount) {
        System.out.println("Processing PayPal payment of $" + amount);
        System.out.println("PayPal Account: " + email);
        System.out.println("Authenticating with PayPal...");
        System.out.println("Payment completed via PayPal! Transaction ID: PP-" + System.currentTimeMillis());
    }
    
    @Override
    public String getPaymentMethod() {
        return "PayPal";
    }
    
    @Override
    public String getPaymentDetails() {
        return "Account: " + email;
    }
}