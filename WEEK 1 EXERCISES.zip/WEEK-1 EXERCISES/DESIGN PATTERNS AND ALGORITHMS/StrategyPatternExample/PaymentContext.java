package StrategyPatternExample;

public class PaymentContext {
    private PaymentStrategy paymentStrategy;
    private String customerName;
    
    public PaymentContext(String customerName) {
        this.customerName = customerName;
        this.paymentStrategy = null;
    }
    
    public void setPaymentStrategy(PaymentStrategy strategy) {
        this.paymentStrategy = strategy;
    }
    
    public void executePayment(double amount) {
        if (paymentStrategy == null) {
            throw new IllegalStateException("Payment strategy not set!");
        }
        System.out.println("\n========================================");
        System.out.println("Customer: " + customerName);
        System.out.println("Payment Method: " + paymentStrategy.getPaymentMethod());
        System.out.println("Payment Details: " + paymentStrategy.getPaymentDetails());
        System.out.println("Amount: $" + amount);
        System.out.println("----------------------------------------");
        paymentStrategy.pay(amount);
        System.out.println("========================================\n");
    }
    
    public String getCustomerName() {
        return customerName;
    }
}
