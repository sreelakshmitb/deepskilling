package StrategyPatternExample;

public class UpiPayment implements PaymentStrategy {
    private String upiId;
    private String upiApp;
    
    public UpiPayment(String upiId, String upiApp) {
        this.upiId = upiId;
        this.upiApp = upiApp;
    }
    
    @Override
    public void pay(double amount) {
        System.out.println("Processing UPI payment of ₹" + (amount * 83.50));
        System.out.println("UPI ID: " + upiId);
        System.out.println("UPI App: " + upiApp);
        System.out.println("Sending payment request...");
        System.out.println("UPI payment successful! UPI Ref: " + generateUpiReference());
    }
    
    private String generateUpiReference() {
        return "UPI" + System.currentTimeMillis() + "IND";
    }
    
    @Override
    public String getPaymentMethod() {
        return "UPI";
    }
    
    @Override
    public String getPaymentDetails() {
        return "UPI ID: " + upiId + " (" + upiApp + ")";
    }
}