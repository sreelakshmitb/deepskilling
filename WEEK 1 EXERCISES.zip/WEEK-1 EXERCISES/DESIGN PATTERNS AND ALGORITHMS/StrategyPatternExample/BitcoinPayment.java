package StrategyPatternExample;

public class BitcoinPayment implements PaymentStrategy {
    private String walletAddress;
    private double bitcoinRate;
    
    public BitcoinPayment(String walletAddress) {
        this.walletAddress = walletAddress;
        this.bitcoinRate = 65000.00;
    }
    
    @Override
    public void pay(double amount) {
        double btcAmount = amount / bitcoinRate;
        System.out.println("Processing Bitcoin payment of $" + amount);
        System.out.println("Wallet Address: " + walletAddress);
        System.out.println("BTC Amount: " + String.format("%.8f", btcAmount) + " BTC");
        System.out.println("Broadcasting transaction to blockchain...");
        System.out.println("Transaction confirmed! TXID: " + generateTransactionId());
    }
    
    private String generateTransactionId() {
        return "0x" + Long.toHexString(System.currentTimeMillis()) + 
               Long.toHexString(System.nanoTime()).substring(0, 8);
    }
    
    @Override
    public String getPaymentMethod() {
        return "Bitcoin";
    }
    
    @Override
    public String getPaymentDetails() {
        return "Wallet: " + walletAddress.substring(0, 10) + "...";
    }
}