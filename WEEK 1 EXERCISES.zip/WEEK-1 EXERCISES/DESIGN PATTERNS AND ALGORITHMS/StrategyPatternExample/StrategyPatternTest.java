package StrategyPatternExample;

public class StrategyPatternTest {
    public static void main(String[] args) {
        System.out.println("=== Payment System with Strategy Pattern ===\n");
        
        PaymentContext context = new PaymentContext("John Doe");
        
        System.out.println("1. Credit Card Payment:");
        PaymentStrategy creditCard = new CreditCardPayment(
            "1234567890123456",
            "John Doe",
            "12/25"
        );
        context.setPaymentStrategy(creditCard);
        context.executePayment(149.99);
        
        System.out.println("2. PayPal Payment:");
        PaymentStrategy paypal = new PayPalPayment("john.doe@example.com");
        context.setPaymentStrategy(paypal);
        context.executePayment(75.50);
        
        System.out.println("3. Bitcoin Payment:");
        PaymentStrategy bitcoin = new BitcoinPayment(
            "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
        );
        context.setPaymentStrategy(bitcoin);
        context.executePayment(250.00);
        
        System.out.println("4. UPI Payment:");
        PaymentStrategy upi = new UpiPayment("john.doe@upi", "Google Pay");
        context.setPaymentStrategy(upi);
        context.executePayment(100.00);
        
        System.out.println("5. Dynamic Payment Switching:");
        PaymentContext anotherContext = new PaymentContext("Jane Smith");
        PaymentStrategy[] strategies = {
            new CreditCardPayment("9876543210987654", "Jane Smith", "11/24"),
            new PayPalPayment("jane.smith@example.com"),
            new BitcoinPayment("1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2"),
            new UpiPayment("jane.smith@paytm", "Paytm")
        };
        double[] amounts = {299.99, 150.00, 500.00, 50.00};
        String[] paymentNames = {"Credit Card", "PayPal", "Bitcoin", "UPI"};
        
        for (int i = 0; i < strategies.length; i++) {
            System.out.println("--- Switching to " + paymentNames[i] + " ---");
            anotherContext.setPaymentStrategy(strategies[i]);
            anotherContext.executePayment(amounts[i]);
        }
        
        System.out.println("6. Same customer using different payment methods:");
        System.out.println("\n--- Customer: " + context.getCustomerName() + " ---");
        
        System.out.println("\nPaying with Credit Card:");
        context.setPaymentStrategy(creditCard);
        context.executePayment(50.00);
        
        System.out.println("Paying with PayPal:");
        context.setPaymentStrategy(paypal);
        context.executePayment(75.00);
        
        System.out.println("Paying with UPI:");
        context.setPaymentStrategy(upi);
        context.executePayment(30.00);
        
        System.out.println("Paying with Bitcoin:");
        context.setPaymentStrategy(bitcoin);
        context.executePayment(100.00);
    }
}