package StrategyPatternExample;

public class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;
    private String cardHolderName;
    private String expiryDate;
    
    public CreditCardPayment(String cardNumber, String cardHolderName, String expiryDate) {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
        this.expiryDate = expiryDate;
    }
    
    @Override
    public void pay(double amount) {
        System.out.println("Processing credit card payment of $" + amount);
        System.out.println("Card: " + maskCardNumber(cardNumber));
        System.out.println("Card Holder: " + cardHolderName);
        System.out.println("Expiry: " + expiryDate);
        System.out.println("Processing payment...");
        System.out.println("Payment approved! Transaction ID: CC-" + System.currentTimeMillis());
    }
    
    private String maskCardNumber(String cardNumber) {
        if (cardNumber.length() >= 4) {
            return "XXXX-XXXX-XXXX-" + cardNumber.substring(cardNumber.length() - 4);
        }
        return "XXXX-XXXX-XXXX-XXXX";
    }
    
    @Override
    public String getPaymentMethod() {
        return "Credit Card";
    }
    
    @Override
    public String getPaymentDetails() {
        return "Card ending in " + cardNumber.substring(cardNumber.length() - 4);
    }
}