package DecoratorPatternExample;

public class WhatsAppNotifierDecorator extends NotifierDecorator {
    private String phoneNumber;
    
    public WhatsAppNotifierDecorator(Notifier notifier, String phoneNumber) {
        super(notifier);
        this.phoneNumber = phoneNumber;
    }
    
    @Override
    public void send(String message) {
        super.send(message);
        sendWhatsApp(message);
    }
    
    private void sendWhatsApp(String message) {
        System.out.println("Sending WhatsApp message to " + phoneNumber + ": " + message);
    }
    
    @Override
    public String getType() {
        return super.getType() + " + WhatsApp";
    }
}