package DecoratorPatternExample;

public interface Notifier {
    void send(String message);
    String getType();
}