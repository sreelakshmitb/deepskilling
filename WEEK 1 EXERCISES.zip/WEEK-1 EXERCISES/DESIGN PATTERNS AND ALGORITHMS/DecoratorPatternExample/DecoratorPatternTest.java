package DecoratorPatternExample;

public class DecoratorPatternTest {
    public static void main(String[] args) {
        System.out.println("=== Notification System ===\n");
        
        System.out.println("1. Sending via Email only:");
        Notifier emailNotifier = new EmailNotifier("user@example.com");
        emailNotifier.send("Your account has been created!");
        System.out.println("Notification type: " + emailNotifier.getType());
        System.out.println();
        
        System.out.println("2. Sending via Email + SMS:");
        Notifier emailAndSMS = new SMSNotifierDecorator(
            new EmailNotifier("user@example.com"), 
            "+1234567890"
        );
        emailAndSMS.send("Your account has been verified!");
        System.out.println("Notification type: " + emailAndSMS.getType());
        System.out.println();
        
        System.out.println("3. Sending via Email + Slack:");
        Notifier emailAndSlack = new SlackNotifierDecorator(
            new EmailNotifier("user@example.com"), 
            "general"
        );
        emailAndSlack.send("New login detected from new device!");
        System.out.println("Notification type: " + emailAndSlack.getType());
        System.out.println();
        
        System.out.println("4. Sending via Email + SMS + Slack:");
        Notifier emailSMSAndSlack = new SlackNotifierDecorator(
            new SMSNotifierDecorator(
                new EmailNotifier("user@example.com"), 
                "+1234567890"
            ), 
            "alerts"
        );
        emailSMSAndSlack.send("Security alert: Suspicious activity detected!");
        System.out.println("Notification type: " + emailSMSAndSlack.getType());
        System.out.println();
        
        System.out.println("5. Sending via Email + SMS + Slack + WhatsApp:");
        Notifier allChannels = new WhatsAppNotifierDecorator(
            new SlackNotifierDecorator(
                new SMSNotifierDecorator(
                    new EmailNotifier("user@example.com"), 
                    "+1234567890"
                ), 
                "emergency"
            ), 
            "+9876543210"
        );
        allChannels.send("URGENT: System maintenance required immediately!");
        System.out.println("Notification type: " + allChannels.getType());
        System.out.println();
        
        System.out.println("6. Dynamic notification building for different users:");
        buildAndSendNotification("Normal User", "Your subscription is active!", 
            new EmailNotifier("normal@example.com"));
        
        buildAndSendNotification("Premium User", "Your premium subscription is active!", 
            new SMSNotifierDecorator(
                new EmailNotifier("premium@example.com"), 
                "+1111111111"
            ));
        
        buildAndSendNotification("VIP User", "VIP access granted with all features!", 
            new WhatsAppNotifierDecorator(
                new SlackNotifierDecorator(
                    new SMSNotifierDecorator(
                        new EmailNotifier("vip@example.com"), 
                        "+2222222222"
                    ), 
                    "vip-channel"
                ), 
                "+3333333333"
            ));
    }
    
    private static void buildAndSendNotification(String userType, String message, Notifier notifier) {
        System.out.println("\n--- " + userType + " ---");
        notifier.send(message);
        System.out.println("Notification type: " + notifier.getType());
    }
}