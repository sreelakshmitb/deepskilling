package DecoratorPatternExample;

public class SMSNotifierDecorator extends NotifierDecorator {
    private String phoneNumber;
    
    public SMSNotifierDecorator(Notifier notifier, String phoneNumber) {
        super(notifier);
        this.phoneNumber = phoneNumber;
    }
    
    @Override
    public void send(String message) {
        super.send(message);
        sendSMS(message);
    }
    
    private void sendSMS(String message) {
        System.out.println("Sending SMS to " + phoneNumber + ": " + message);
    }
    
    @Override
    public String getType() {
        return super.getType() + " + SMS";
    }
}