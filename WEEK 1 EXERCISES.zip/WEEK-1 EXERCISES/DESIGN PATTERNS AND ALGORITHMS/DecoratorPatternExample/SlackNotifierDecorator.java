package DecoratorPatternExample;

public class SlackNotifierDecorator extends NotifierDecorator {
    private String slackChannel;
    
    public SlackNotifierDecorator(Notifier notifier, String slackChannel) {
        super(notifier);
        this.slackChannel = slackChannel;
    }
    
    @Override
    public void send(String message) {
        super.send(message);
        sendSlackMessage(message);
    }
    
    private void sendSlackMessage(String message) {
        System.out.println("Sending Slack message to channel #" + slackChannel + ": " + message);
    }
    
    @Override
    public String getType() {
        return super.getType() + " + Slack";
    }
}