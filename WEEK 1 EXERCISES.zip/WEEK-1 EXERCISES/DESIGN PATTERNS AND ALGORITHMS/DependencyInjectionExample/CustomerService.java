package DependencyInjectionExample;


public class CustomerService {
    private CustomerRepository customerRepository;
    
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }
    
    public Customer getCustomerById(String id) {
        if (id == null || id.isEmpty()) {
            System.out.println("Invalid customer ID");
            return null;
        }
        
        Customer customer = customerRepository.findCustomerById(id);
        if (customer != null) {
            System.out.println("Found customer: " + customer.getName());
            return customer;
        } else {
            System.out.println("Customer not found with ID: " + id);
            return null;
        }
    }
    
    public void addCustomer(Customer customer) {
        if (customer == null || customer.getId() == null) {
            System.out.println("Invalid customer data");
            return;
        }
        
        if (customerRepository.customerExists(customer.getId())) {
            System.out.println("Customer with ID " + customer.getId() + " already exists");
        } else {
            customerRepository.saveCustomer(customer);
        }
    }
    
    public void updateCustomer(String id, String name, String email, String phone, String address) {
        Customer existing = customerRepository.findCustomerById(id);
        if (existing != null) {
            existing.setName(name);
            existing.setEmail(email);
            existing.setPhone(phone);
            existing.setAddress(address);
            customerRepository.saveCustomer(existing);
            System.out.println("Customer updated successfully");
        } else {
            System.out.println("Customer not found with ID: " + id);
        }
    }
    
    public void deleteCustomer(String id) {
        if (customerRepository.customerExists(id)) {
            customerRepository.deleteCustomer(id);
        } else {
            System.out.println("Customer not found with ID: " + id);
        }
    }
    
    public boolean isCustomerExists(String id) {
        return customerRepository.customerExists(id);
    }
    
    public int getTotalCustomers() {
        return customerRepository.getTotalCustomers();
    }
    
    public void displayCustomerDetails(String id) {
        Customer customer = getCustomerById(id);
        if (customer != null) {
            System.out.println("\n=== Customer Details ===");
            System.out.println("ID       : " + customer.getId());
            System.out.println("Name     : " + customer.getName());
            System.out.println("Email    : " + customer.getEmail());
            System.out.println("Phone    : " + customer.getPhone());
            System.out.println("Address  : " + customer.getAddress());
            System.out.println("========================\n");
        }
    }
}