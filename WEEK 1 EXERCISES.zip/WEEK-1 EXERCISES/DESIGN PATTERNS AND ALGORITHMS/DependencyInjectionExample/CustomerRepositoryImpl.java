package DependencyInjectionExample;

import java.util.HashMap;
import java.util.Map;

public class CustomerRepositoryImpl implements CustomerRepository {
    private Map<String, Customer> customerDatabase;
    
    public CustomerRepositoryImpl() {
        this.customerDatabase = new HashMap<>();
        initializeTestData();
    }
    
    private void initializeTestData() {
        customerDatabase.put("C001", new Customer("C001", "John Doe", "john.doe@email.com", "555-0101", "123 Main St"));
        customerDatabase.put("C002", new Customer("C002", "Jane Smith", "jane.smith@email.com", "555-0102", "456 Oak Ave"));
        customerDatabase.put("C003", new Customer("C003", "Bob Johnson", "bob.johnson@email.com", "555-0103", "789 Pine Rd"));
        customerDatabase.put("C004", new Customer("C004", "Alice Brown", "alice.brown@email.com", "555-0104", "321 Elm St"));
        customerDatabase.put("C005", new Customer("C005", "Charlie Wilson", "charlie.w@email.com", "555-0105", "654 Maple Dr"));
    }
    
    @Override
    public Customer findCustomerById(String id) {
        if (customerDatabase.containsKey(id)) {
            return customerDatabase.get(id);
        }
        return null;
    }
    
    @Override
    public void saveCustomer(Customer customer) {
        if (customer != null && customer.getId() != null) {
            customerDatabase.put(customer.getId(), customer);
            System.out.println("Customer saved successfully: " + customer.getId());
        } else {
            System.out.println("Cannot save customer: Invalid customer data");
        }
    }
    
    @Override
    public void deleteCustomer(String id) {
        if (customerDatabase.containsKey(id)) {
            customerDatabase.remove(id);
            System.out.println("Customer deleted successfully: " + id);
        } else {
            System.out.println("Customer not found: " + id);
        }
    }
    
    @Override
    public boolean customerExists(String id) {
        return customerDatabase.containsKey(id);
    }
    
    @Override
    public int getTotalCustomers() {
        return customerDatabase.size();
    }
    
    public void displayAllCustomers() {
        System.out.println("\n--- All Customers in Database ---");
        for (Customer customer : customerDatabase.values()) {
            System.out.println(customer);
        }
        System.out.println("Total: " + customerDatabase.size() + " customers\n");
    }
}