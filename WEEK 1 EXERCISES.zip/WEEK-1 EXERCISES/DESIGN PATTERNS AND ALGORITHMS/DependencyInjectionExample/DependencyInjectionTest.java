package DependencyInjectionExample;

public class DependencyInjectionTest {
    public static void main(String[] args) {
        System.out.println("=== Customer Management System (Dependency Injection) ===\n");
        
        CustomerRepository repository = new CustomerRepositoryImpl();
        
        CustomerService service = new CustomerService(repository);
        
        System.out.println("1. Display All Customers:");
        ((CustomerRepositoryImpl) repository).displayAllCustomers();
        
        System.out.println("2. Find Customer by ID (C001):");
        service.displayCustomerDetails("C001");
        
        System.out.println("3. Find Customer by ID (C003):");
        service.displayCustomerDetails("C003");
        
        System.out.println("4. Find Non-Existent Customer (C999):");
        service.displayCustomerDetails("C999");
        
        System.out.println("5. Add New Customer:");
        Customer newCustomer = new Customer(
            "C006", 
            "Sarah Johnson", 
            "sarah.j@email.com", 
            "555-0106", 
            "987 Cedar Ln"
        );
        service.addCustomer(newCustomer);
        ((CustomerRepositoryImpl) repository).displayAllCustomers();
        
        System.out.println("6. Update Existing Customer (C002):");
        service.updateCustomer("C002", "Jane Wilson", "jane.wilson@email.com", "555-0202", "123 Oak Ave");
        service.displayCustomerDetails("C002");
        
        System.out.println("7. Delete Customer (C005):");
        service.deleteCustomer("C005");
        ((CustomerRepositoryImpl) repository).displayAllCustomers();
        
        System.out.println("8. Check Customer Existence:");
        System.out.println("Customer C001 exists: " + service.isCustomerExists("C001"));
        System.out.println("Customer C999 exists: " + service.isCustomerExists("C999"));
        
        System.out.println("9. Get Total Customers:");
        System.out.println("Total customers: " + service.getTotalCustomers());
        
        System.out.println("10. Multiple Operations Demo:");
        performMultipleOperations(service, repository);
        
        System.out.println("11. Demonstrate Dependency Injection with Different Repository:");
        CustomerRepository anotherRepository = new AnotherCustomerRepositoryImpl();
        CustomerService anotherService = new CustomerService(anotherRepository);
        System.out.println("New service created with different repository implementation:");
        anotherService.displayCustomerDetails("C001");
    }
    
    private static void performMultipleOperations(CustomerService service, CustomerRepository repository) {
        System.out.println("\n--- Adding Multiple Customers ---");
        Customer[] newCustomers = {
            new Customer("C007", "Mike Davis", "mike.d@email.com", "555-0107", "159 Maple Ave"),
            new Customer("C008", "Lisa Chen", "lisa.c@email.com", "555-0108", "753 Birch St"),
            new Customer("C009", "Tom Jackson", "tom.j@email.com", "555-0109", "951 Spruce Dr")
        };
        
        for (Customer customer : newCustomers) {
            service.addCustomer(customer);
        }
        
        ((CustomerRepositoryImpl) repository).displayAllCustomers();
        
        System.out.println("--- Batch Update Customers ---");
        for (Customer customer : newCustomers) {
            String newEmail = customer.getName().toLowerCase().replace(" ", ".") + "@email.com";
            customer.setEmail(newEmail);
            service.updateCustomer(
                customer.getId(), 
                customer.getName(), 
                newEmail, 
                "555-0" + (100 + Integer.parseInt(customer.getId().substring(1))), 
                customer.getAddress()
            );
        }
        
        ((CustomerRepositoryImpl) repository).displayAllCustomers();
    }
}