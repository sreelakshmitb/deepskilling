package DependencyInjectionExample;

import java.util.HashMap;
import java.util.Map;

public class AnotherCustomerRepositoryImpl implements CustomerRepository {
    private Map<String, Customer> customerDatabase;
    
    public AnotherCustomerRepositoryImpl() {
        this.customerDatabase = new HashMap<>();
        customerDatabase.put("C001", new Customer("C001", "John Doe (Another)", "john.another@email.com", "555-0999", "999 Test St"));
        customerDatabase.put("C002", new Customer("C002", "Jane Smith (Another)", "jane.another@email.com", "555-0998", "888 Test Ave"));
    }
    
    @Override
    public Customer findCustomerById(String id) {
        return customerDatabase.get(id);
    }
    
    @Override
    public void saveCustomer(Customer customer) {
        customerDatabase.put(customer.getId(), customer);
    }
    
    @Override
    public void deleteCustomer(String id) {
        customerDatabase.remove(id);
    }
    
    @Override
    public boolean customerExists(String id) {
        return customerDatabase.containsKey(id);
    }
    
    @Override
    public int getTotalCustomers() {
        return customerDatabase.size();
    }
}
